Hi Kyle, I hope you are reading this, just a quick one!

I had to export my DB, cause it's a little bit different than the DB on the Moodle, so you can use it instead of the default one. (I'll leave it in the separated folder).

And one more thing, there is a folder with screenshots, to confirm that everything works from my side.

GITHUB LINK: https://github.com/ejtun91/ecommproject21.git
