-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2021 at 11:29 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `customerorders`
--

CREATE TABLE `customerorders` (
  `id` int(11) NOT NULL,
  `orderby` varchar(50) CHARACTER SET latin1 NOT NULL,
  `orderstatus` varchar(50) CHARACTER SET latin1 NOT NULL DEFAULT 'PENDING',
  `items` varchar(500) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `total` int(11) DEFAULT 0,
  `address` varchar(50) DEFAULT '0',
  `time` datetime DEFAULT curdate()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customerorders`
--

INSERT INTO `customerorders` (`id`, `orderby`, `orderstatus`, `items`, `total`, `address`, `time`) VALUES
(40, 'customer', 'GETTING READY', 'chocolate doughnut-3', 6, 'cluain dara', '2021-03-11 00:00:00'),
(41, 'ante1', 'Complete', 'chocolate doughnut-3,Sprite-2', 8, 'cluain dara', '2021-03-26 00:00:00'),
(42, '', 'Complete', 'Jam Doughnut-3', 3, 'cluain dara', '2021-03-26 00:00:00'),
(43, 'customer', 'Complete', 'chocolate doughnut-2', 4, 'cluain dara', '2021-04-16 00:00:00'),
(44, 'antonio', 'GETTING READY', 'chocolate doughnut-2,plain ring-2', 8, 'cluain dara 1', '2021-04-23 00:00:00'),
(45, 'antonio', 'GETTING READY', 'Jam Doughnut-3,Iced Doughnut-3,plain ring-3', 12, 'cluain dara', '2021-04-23 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT '0',
  `price` int(11) DEFAULT 0,
  `picture` longblob DEFAULT NULL,
  `picturepath` varchar(100) DEFAULT NULL,
  `productname` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `picture`, `picturepath`, `productname`) VALUES
(1, 'chocolate doughnut', 2, 0x284e554c4c29, 'images/pic1.jpg', 'chocolate'),
(2, 'plain ring', 2, NULL, 'images/pic2.jpg', NULL),
(3, 'Lemon Doughnut', 2, NULL, 'images/pic3.jpg', NULL),
(4, 'Sprinkle Doughnut', 1, NULL, 'images/pic4.jpg', NULL),
(5, 'Jam Doughnut', 1, NULL, 'images/pic5.jpg', NULL),
(6, 'Iced Doughnut', 1, NULL, 'images/pic6.jpg', NULL),
(7, 'Sprite', 1, NULL, 'images/pic7.jpg', NULL),
(8, 'Fanta', 1, NULL, 'images/pic8.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT '0',
  `password` varchar(50) DEFAULT '0',
  `acctype` varchar(50) DEFAULT '0',
  `address` varchar(50) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `acctype`, `address`) VALUES
(8, 'customer', 'customer@domain.com', '1', 'customer', '0'),
(9, 'driver', 'driver@domain.com', '1', 'driver', '0'),
(10, 'manager', 'manager@domain.com', '1', 'manager', '0'),
(11, 'ante1', 'ante@gmail.com', '12', 'customer', '0'),
(12, 'antonio', 'antonio@gmail.com', '12345', 'customer', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customerorders`
--
ALTER TABLE `customerorders`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customerorders`
--
ALTER TABLE `customerorders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
